--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1
-- Dumped by pg_dump version 16.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE proj_ea;
--
-- Name: proj_ea; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE proj_ea WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Italian_Italy.1252';


ALTER DATABASE proj_ea OWNER TO postgres;

\connect proj_ea

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: addresses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.addresses (
    is_default boolean NOT NULL,
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    additional_info character varying(255),
    city character varying(255) NOT NULL,
    country character varying(255) NOT NULL,
    full_name character varying(255) NOT NULL,
    phone_number character varying(255) NOT NULL,
    postal_code character varying(255) NOT NULL,
    province character varying(255) NOT NULL,
    street character varying(255) NOT NULL
);


ALTER TABLE public.addresses OWNER TO postgres;

--
-- Name: brand_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.brand_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.brand_sequence OWNER TO postgres;

--
-- Name: brands; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.brands (
    id bigint NOT NULL,
    description character varying(1000) NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.brands OWNER TO postgres;

--
-- Name: cart_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cart_items (
    quantity integer NOT NULL,
    product_id bigint NOT NULL,
    cart_id uuid,
    id uuid NOT NULL
);


ALTER TABLE public.cart_items OWNER TO postgres;

--
-- Name: carts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.carts (
    id uuid NOT NULL,
    user_id uuid
);


ALTER TABLE public.carts OWNER TO postgres;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    id bigint NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: category_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.category_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.category_sequence OWNER TO postgres;

--
-- Name: invalid_token_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.invalid_token_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.invalid_token_sequence OWNER TO postgres;

--
-- Name: invalid_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invalid_tokens (
    expiration_date timestamp without time zone NOT NULL,
    id bigint NOT NULL,
    token character varying(255) NOT NULL
);


ALTER TABLE public.invalid_tokens OWNER TO postgres;

--
-- Name: order_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.order_items (
    partial_cost numeric(38,2) NOT NULL,
    quantity integer NOT NULL,
    product_id bigint NOT NULL,
    id uuid NOT NULL,
    order_id uuid,
    product_name character varying(255) NOT NULL
);


ALTER TABLE public.order_items OWNER TO postgres;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    total_cost numeric(38,2) NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    address_id uuid NOT NULL,
    id uuid NOT NULL,
    payment_method_id uuid NOT NULL,
    user_id uuid NOT NULL,
    status character varying(255) NOT NULL,
    CONSTRAINT orders_status_check CHECK (((status)::text = ANY ((ARRAY['CREATED'::character varying, 'PROCESSING'::character varying, 'SHIPPED'::character varying, 'DELIVERED'::character varying, 'CANCELLED'::character varying, 'RETURNED'::character varying])::text[])))
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: payment_methods; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.payment_methods (
    is_default boolean NOT NULL,
    card_number character varying(16) NOT NULL,
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    expire_month character varying(255) NOT NULL,
    expire_year character varying(255) NOT NULL,
    owner character varying(255) NOT NULL
);


ALTER TABLE public.payment_methods OWNER TO postgres;

--
-- Name: product_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.product_sequence OWNER TO postgres;

--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    on_sale boolean NOT NULL,
    price numeric(38,2) NOT NULL,
    quantity integer NOT NULL,
    sale_price numeric(38,2),
    shipping_cost numeric(38,2) NOT NULL,
    brand_id bigint NOT NULL,
    category_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    id bigint NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    availability character varying(255) NOT NULL,
    description character varying(255) NOT NULL,
    ingredients character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    nutritional_values character varying(255) NOT NULL,
    weight character varying(255) NOT NULL,
    CONSTRAINT products_availability_check CHECK (((availability)::text = ANY ((ARRAY['IN_STOCK'::character varying, 'OUT_OF_STOCK'::character varying, 'PRE_ORDER'::character varying, 'DISCONTINUED'::character varying])::text[])))
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: products_image; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products_image (
    product_id bigint,
    id character varying(36) NOT NULL,
    description character varying(255),
    url_photo character varying(255) NOT NULL
);


ALTER TABLE public.products_image OWNER TO postgres;

--
-- Name: shared_wishlist_access; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shared_wishlist_access (
    id bigint NOT NULL,
    user_id uuid NOT NULL,
    wishlist_id uuid NOT NULL
);


ALTER TABLE public.shared_wishlist_access OWNER TO postgres;

--
-- Name: sharedwishlist_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sharedwishlist_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sharedwishlist_sequence OWNER TO postgres;

--
-- Name: user_image; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_image (
    user_id uuid,
    id character varying(36) NOT NULL,
    description character varying(255),
    url_photo character varying(255) NOT NULL
);


ALTER TABLE public.user_image OWNER TO postgres;

--
-- Name: user_payment_methods; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_payment_methods (
    payment_method_id uuid NOT NULL,
    user_id uuid NOT NULL
);


ALTER TABLE public.user_payment_methods OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    email_verified boolean NOT NULL,
    id uuid NOT NULL,
    email character varying(255) NOT NULL,
    first_name character varying(255) NOT NULL,
    last_name character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    phone_number character varying(255),
    provider character varying(255) NOT NULL,
    role character varying(255) NOT NULL,
    status character varying(255) NOT NULL,
    username character varying(255) NOT NULL,
    CONSTRAINT users_provider_check CHECK (((provider)::text = ANY ((ARRAY['LOCAL'::character varying, 'KEYCLOAK'::character varying, 'GOOGLE'::character varying])::text[]))),
    CONSTRAINT users_role_check CHECK (((role)::text = ANY ((ARRAY['USER'::character varying, 'ADMIN'::character varying, 'SUPPLIER'::character varying])::text[]))),
    CONSTRAINT users_status_check CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'INACTIVE'::character varying, 'BANNED'::character varying, 'SUSPENDED'::character varying, 'CANCELLED'::character varying])::text[])))
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: wishlist_products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wishlist_products (
    product_id bigint NOT NULL,
    wishlist_id uuid NOT NULL
);


ALTER TABLE public.wishlist_products OWNER TO postgres;

--
-- Name: wishlists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.wishlists (
    created_at timestamp(6) without time zone NOT NULL,
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    visibility character varying(255) NOT NULL,
    wishlist_name character varying(255) NOT NULL,
    CONSTRAINT wishlists_visibility_check CHECK (((visibility)::text = ANY ((ARRAY['PUBLIC'::character varying, 'PRIVATE'::character varying, 'SHARED'::character varying])::text[])))
);


ALTER TABLE public.wishlists OWNER TO postgres;

--
-- Data for Name: addresses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.addresses (is_default, id, user_id, additional_info, city, country, full_name, phone_number, postal_code, province, street) FROM stdin;
\.
COPY public.addresses (is_default, id, user_id, additional_info, city, country, full_name, phone_number, postal_code, province, street) FROM '$$PATH$$/4973.dat';

--
-- Data for Name: brands; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.brands (id, description, name) FROM stdin;
\.
COPY public.brands (id, description, name) FROM '$$PATH$$/4974.dat';

--
-- Data for Name: cart_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cart_items (quantity, product_id, cart_id, id) FROM stdin;
\.
COPY public.cart_items (quantity, product_id, cart_id, id) FROM '$$PATH$$/4975.dat';

--
-- Data for Name: carts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.carts (id, user_id) FROM stdin;
\.
COPY public.carts (id, user_id) FROM '$$PATH$$/4976.dat';

--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (id, name) FROM stdin;
\.
COPY public.categories (id, name) FROM '$$PATH$$/4977.dat';

--
-- Data for Name: invalid_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.invalid_tokens (expiration_date, id, token) FROM stdin;
\.
COPY public.invalid_tokens (expiration_date, id, token) FROM '$$PATH$$/4978.dat';

--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.order_items (partial_cost, quantity, product_id, id, order_id, product_name) FROM stdin;
\.
COPY public.order_items (partial_cost, quantity, product_id, id, order_id, product_name) FROM '$$PATH$$/4979.dat';

--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (total_cost, created_at, updated_at, address_id, id, payment_method_id, user_id, status) FROM stdin;
\.
COPY public.orders (total_cost, created_at, updated_at, address_id, id, payment_method_id, user_id, status) FROM '$$PATH$$/4980.dat';

--
-- Data for Name: payment_methods; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.payment_methods (is_default, card_number, id, user_id, expire_month, expire_year, owner) FROM stdin;
\.
COPY public.payment_methods (is_default, card_number, id, user_id, expire_month, expire_year, owner) FROM '$$PATH$$/4981.dat';

--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (on_sale, price, quantity, sale_price, shipping_cost, brand_id, category_id, created_at, id, updated_at, availability, description, ingredients, name, nutritional_values, weight) FROM stdin;
\.
COPY public.products (on_sale, price, quantity, sale_price, shipping_cost, brand_id, category_id, created_at, id, updated_at, availability, description, ingredients, name, nutritional_values, weight) FROM '$$PATH$$/4982.dat';

--
-- Data for Name: products_image; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products_image (product_id, id, description, url_photo) FROM stdin;
\.
COPY public.products_image (product_id, id, description, url_photo) FROM '$$PATH$$/4983.dat';

--
-- Data for Name: shared_wishlist_access; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shared_wishlist_access (id, user_id, wishlist_id) FROM stdin;
\.
COPY public.shared_wishlist_access (id, user_id, wishlist_id) FROM '$$PATH$$/4984.dat';

--
-- Data for Name: user_image; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_image (user_id, id, description, url_photo) FROM stdin;
\.
COPY public.user_image (user_id, id, description, url_photo) FROM '$$PATH$$/4985.dat';

--
-- Data for Name: user_payment_methods; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_payment_methods (payment_method_id, user_id) FROM stdin;
\.
COPY public.user_payment_methods (payment_method_id, user_id) FROM '$$PATH$$/4986.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (email_verified, id, email, first_name, last_name, password, phone_number, provider, role, status, username) FROM stdin;
\.
COPY public.users (email_verified, id, email, first_name, last_name, password, phone_number, provider, role, status, username) FROM '$$PATH$$/4987.dat';

--
-- Data for Name: wishlist_products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.wishlist_products (product_id, wishlist_id) FROM stdin;
\.
COPY public.wishlist_products (product_id, wishlist_id) FROM '$$PATH$$/4988.dat';

--
-- Data for Name: wishlists; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.wishlists (created_at, id, user_id, visibility, wishlist_name) FROM stdin;
\.
COPY public.wishlists (created_at, id, user_id, visibility, wishlist_name) FROM '$$PATH$$/4989.dat';

--
-- Name: brand_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.brand_sequence', 16, true);


--
-- Name: category_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.category_sequence', 13, true);


--
-- Name: invalid_token_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.invalid_token_sequence', 1, false);


--
-- Name: product_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_sequence', 22, true);


--
-- Name: sharedwishlist_sequence; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sharedwishlist_sequence', 1, false);


--
-- Name: addresses addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.addresses
    ADD CONSTRAINT addresses_pkey PRIMARY KEY (id);


--
-- Name: brands brands_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.brands
    ADD CONSTRAINT brands_pkey PRIMARY KEY (id);


--
-- Name: cart_items cart_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT cart_items_pkey PRIMARY KEY (id);


--
-- Name: carts carts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT carts_pkey PRIMARY KEY (id);


--
-- Name: carts carts_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT carts_user_id_key UNIQUE (user_id);


--
-- Name: categories categories_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_name_key UNIQUE (name);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: invalid_tokens invalid_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invalid_tokens
    ADD CONSTRAINT invalid_tokens_pkey PRIMARY KEY (id);


--
-- Name: invalid_tokens invalid_tokens_token_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invalid_tokens
    ADD CONSTRAINT invalid_tokens_token_key UNIQUE (token);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: payment_methods payment_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_pkey PRIMARY KEY (id);


--
-- Name: products_image products_image_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products_image
    ADD CONSTRAINT products_image_pkey PRIMARY KEY (id);


--
-- Name: products_image products_image_product_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products_image
    ADD CONSTRAINT products_image_product_id_key UNIQUE (product_id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: shared_wishlist_access shared_wishlist_access_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shared_wishlist_access
    ADD CONSTRAINT shared_wishlist_access_pkey PRIMARY KEY (id);


--
-- Name: user_image user_image_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_image
    ADD CONSTRAINT user_image_pkey PRIMARY KEY (id);


--
-- Name: user_image user_image_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_image
    ADD CONSTRAINT user_image_user_id_key UNIQUE (user_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: wishlists wishlists_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wishlists
    ADD CONSTRAINT wishlists_pkey PRIMARY KEY (id);


--
-- Name: addresses fk1fa36y2oqhao3wgg2rw1pi459; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.addresses
    ADD CONSTRAINT fk1fa36y2oqhao3wgg2rw1pi459 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: orders fk32ql8ubntj5uh44ph9659tiih; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fk32ql8ubntj5uh44ph9659tiih FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: wishlists fk330pyw2el06fn5g28ypyljt16; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wishlists
    ADD CONSTRAINT fk330pyw2el06fn5g28ypyljt16 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_payment_methods fk6fji64w765usy5so1w2oxcqet; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_payment_methods
    ADD CONSTRAINT fk6fji64w765usy5so1w2oxcqet FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: wishlist_products fk7qhemtvmqs6ke3rj9gacnqa94; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wishlist_products
    ADD CONSTRAINT fk7qhemtvmqs6ke3rj9gacnqa94 FOREIGN KEY (wishlist_id) REFERENCES public.wishlists(id);


--
-- Name: orders fka03ljb6t6oa6mqtoifuwkb0kw; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fka03ljb6t6oa6mqtoifuwkb0kw FOREIGN KEY (payment_method_id) REFERENCES public.payment_methods(id);


--
-- Name: products fka3a4mpsfdf4d2y6r8ra3sc8mv; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT fka3a4mpsfdf4d2y6r8ra3sc8mv FOREIGN KEY (brand_id) REFERENCES public.brands(id);


--
-- Name: carts fkb5o626f86h46m4s7ms6ginnop; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carts
    ADD CONSTRAINT fkb5o626f86h46m4s7ms6ginnop FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: shared_wishlist_access fkb9mci8gt7mw1mdsjsvvvmeyjs; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shared_wishlist_access
    ADD CONSTRAINT fkb9mci8gt7mw1mdsjsvvvmeyjs FOREIGN KEY (wishlist_id) REFERENCES public.wishlists(id);


--
-- Name: order_items fkbioxgbv59vetrxe0ejfubep1w; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT fkbioxgbv59vetrxe0ejfubep1w FOREIGN KEY (order_id) REFERENCES public.orders(id);


--
-- Name: orders fkhlglkvf5i60dv6dn397ethgpt; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fkhlglkvf5i60dv6dn397ethgpt FOREIGN KEY (address_id) REFERENCES public.addresses(id);


--
-- Name: payment_methods fkin7rtmim3ljrrhh5kxbq27s2v; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT fkin7rtmim3ljrrhh5kxbq27s2v FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: user_image fko80y1v1f5vsfflp3jlax0x1c6; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_image
    ADD CONSTRAINT fko80y1v1f5vsfflp3jlax0x1c6 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: products fkog2rp4qthbtt2lfyhfo32lsw9; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT fkog2rp4qthbtt2lfyhfo32lsw9 FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: cart_items fkpcttvuq4mxppo8sxggjtn5i2c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cart_items
    ADD CONSTRAINT fkpcttvuq4mxppo8sxggjtn5i2c FOREIGN KEY (cart_id) REFERENCES public.carts(id);


--
-- Name: wishlist_products fkpj5y3q6hyu53f8q4pd6n7rndc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.wishlist_products
    ADD CONSTRAINT fkpj5y3q6hyu53f8q4pd6n7rndc FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: user_payment_methods fksdknpuy0fsxp4kpwwr6akxipm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_payment_methods
    ADD CONSTRAINT fksdknpuy0fsxp4kpwwr6akxipm FOREIGN KEY (payment_method_id) REFERENCES public.payment_methods(id);


--
-- Name: products_image fksly8833rax50pyabfssnjvn87; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products_image
    ADD CONSTRAINT fksly8833rax50pyabfssnjvn87 FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: shared_wishlist_access fktkqg7o0t88mdd84bcjnyrxauw; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shared_wishlist_access
    ADD CONSTRAINT fktkqg7o0t88mdd84bcjnyrxauw FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

